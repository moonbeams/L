# -*- coding : utf-8 -*-
#calculate the password for vs & vc
#createor:wangzhaolei
#date:2016-04-05

from xmlrpclib import ServerProxy
import socket
import hashlib
import sys
import traceback
import syslog

def rpc_server(ip):
    rpc = ServerProxy('http://%s:9165' % ip)
    socket.setdefaulttimeout(5)
    return rpc
def check_ip(ip):
    if len(ip.split('.')) != 4:
        return False
    return True

def depass(ip):
    if check_ip(ip):
        try:
            phyinfo = rpc_server(ip).do_get_get_phyinfo()
            m1 = hashlib.md5()
            m1.update(phyinfo)
            m2 = m1.hexdigest()
            m3 = m2[6:8] + m2[16:18] + m2[26:28]
            return m3
        #print "password: " + m3 + "\n"
        except:
            return ""
    else:
        return ""

if __name__ == '__main__':
    syslog.openlog("vSpass.py")
    try:
        while True:
            depass()
    except KeyboardInterrupt:
        print "\n"
        sys.exit(0)
    except:
        syslog.syslog(str(traceback.format_exc()))
        print "An error occured,please check if ip is connected or check /var/log/message for detail."
        
         
