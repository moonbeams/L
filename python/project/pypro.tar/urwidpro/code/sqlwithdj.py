import urwid
import sys
sys.path.append("/usr/django_object")
import django
import django_object.settings
from django.conf import settings
settings.configure(defaule_settings=django_object.settings)
from db_object.models import *

#print hosts.objects.values()
#print hosts.objects.filter(host_state="available").values()
print vms.objects.filter(id=1).delete()
