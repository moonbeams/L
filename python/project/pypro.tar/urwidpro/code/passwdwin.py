import sys
sys.path.append("/home/code/python/urwidpro")
import urwid
import re
from vspasswd import vSpass
import os

CURPATH = os.getcwd()
FILENAME = "%s/../vspasswd/vspass" % CURPATH

class GetVSPass():
    def __init__(self):
        pass

    def exit(self,key):
        if key in ["q"]:
            raise urwid.ExitMainLoop()
        if key in ["f2"]:
            self.pile.set_focus(0)
    
    def getpass_fromfile(self,fn):
        with open(fn) as passfile:
            data = passfile.read()
            return data
    
    def savepass_intofile(self,fn,ip,passwd):
        data = self.getpass_fromfile(fn)
        if ip in data:  #ip in vspass
            data_new = data[0:data.index("ip:%s"%ip)] + data[(data.index("ip:%s"%ip)+31):]
        else:
            data_new = data
        ip_pass = "ip:%s passwd:%s\n" % (ip,passwd)
        data_new = ip_pass + data_new
        if ip_pass not in data:   
            with open(fn,"w") as passfile:
                passfile.write(data_new)
        self.txt.set_edit_text("")
        self.result.set_text(data_new)
        
    def decode(self,text,ipweight):
        ip = ipweight.get_edit_text()
        passwd = vSpass.depass(ip)
        if passwd:
            self.txt.set_edit_text("")
            self.savepass_intofile(FILENAME,ip,passwd)
        else:
            self.txt.set_edit_text("please re input")
    
    def CreateGetPassWind(self):
        self.txt = urwid.Edit(u"Input IP:\n")
        button = urwid.Button(u"Get Passwd",on_press=self.decode,user_data=self.txt)
        buttonfix = urwid.Columns([('fixed',20, button)])
        divide = urwid.Divider()
        ipinfo = self.getpass_fromfile(FILENAME)
        self.result = urwid.Text(ipinfo)
        self.pile = urwid.Pile([self.txt,buttonfix,divide,self.result])
        fill = urwid.Filler(self.pile,valign='top')
        loop = urwid.MainLoop(fill,unhandled_input=self.exit)
        loop.run()
        

if __name__ == "__main__":
    screen = GetVSPass()
    screen.CreateGetPassWind()
