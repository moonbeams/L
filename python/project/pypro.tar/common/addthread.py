import threading
import time


def testfunc():
    print 1

class mythread_1():
    def __init__(self,func,args=()):
        self.func = func
        self.args = args
        
    def run(self):
        self.thread = threading.Thread(target=self.func,args=self.args)
        self.thread.setDaemon(True)
        self.thread.start()

#test = mythread_1(testfunc)
#test.run()
