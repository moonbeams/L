import urwid
from passwdwin import GetVSPass

class Main():
    def __init__(self):
        pass
    def exit(self,key):
        if key in "q":
            raise urwid.ExitMainLoop()

    def jump_to_vspass(self,widget):
        del self.fill
        GetVSPass().CreateGetPassWind()

    def mainwin(self):
        button1 = urwid.Button("    vspass" ,on_press=self.jump_to_vspass)
        button1_fix = urwid.Columns([("fixed",20,button1)])

        button2 = urwid.Button("    sqlwithdj")
        button2_fix = urwid.Columns([("fixed",20,button2)])

        pile = urwid.Pile([button1_fix,button2_fix])

        self.fill = urwid.Filler(pile,valign="top")
        loop = urwid.MainLoop(self.fill,unhandled_input=self.exit)
        loop.run()

if __name__ == "__main__":
        Main().mainwin()
