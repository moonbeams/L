import sys
sys.path.append("/home/code/python")
from Tkinter import *
import os
import time
import commands

from common.addthread import mythread_1

HEIGHT = 200
WIDTH = 200
GEOMETRY = '200x200'
#NOTE_GEOMETRY = '200x1'
XTERM_GEOMETRY = '200x182'
XTERM_PID = ''

def get_screen_size(winid,root,uplab,downlab,xtop):
    
    global XTERM_GEOMETRY
    while True:
        time.sleep(1)
        print downlab.winfo_geometry(),XTERM_PID,XTERM_GEOMETRY
        
        if XTERM_GEOMETRY != downlab.winfo_geometry().split('+')[0]:
            print 'a'
            XTERM_GEOMETRY = downlab.winfo_geometry().split('+')[0]
            xtop.reset_xter(XTERM_GEOMETRY)
        else:
            pass


class xterm_option():

    def __init__(self):
        #self.win_id = win_id
        #self.win_geometry = win_geometry
        pass

    def set_xterm(self,win_id,win_geometry=None):
        self.win_id = win_id
        self.win_geometry = win_geometry
        if not self.win_geometry:
            os.system('xterm -into %d  &' % (self.win_id))
        else:
            os.system('xterm -into %d -geometry %s &' % (self.win_id,self.win_geometry))
        self.get_xter_pid()

    def reset_xter(self,new_size):
        global XTERM_PID
        os.system("kill -9 %s" % XTERM_PID)
        #os.system('xterm -into %d -geometry %s -sb &' % (self.win_id,new_size))
        os.system('xterm -into %d -geometry %s &' % (self.win_id,new_size))
        self.get_xter_pid()

    def get_xter_pid(self):
        flag,output = commands.getstatusoutput('ps -ef |grep "xterm -into %d" |grep -v grep |cut -c 9-15' % self.win_id)
        global XTERM_PID
        XTERM_PID = output.strip()

def clear_xterm():
    os.system("ps ax |grep 'xterm -into'|grep -v grep|cut -c 1-5|xargs kill -9")
    

class tkwin():

    def __init__(self):
        pass

    def createwin(self):
        global GEOMETRY,HEIGHT,WIDTH
        self.root = Tk()
        self.root.title("tkterm ")
        self.root.geometry(GEOMETRY+'+0+0')

        #self.fm_up = Frame(self.root,width=WIDTH,height=20,bg='black')
        #self.fm_up.pack()
        #self.fm_down = Frame(self.root,width=WIDTH,height=(HEIGHT-20))
        #self.fm_down.pack()

        self.lab_up = Label(self.root, width=WIDTH, height=1, bg='black')
        self.lab_up.pack()
        self.lab_down = Label(self.root,width=WIDTH,height=(181))
        self.lab_down.pack()

        self.root.protocol("WM_DELETE_WINDOW",self.close)

    def get_winid(self):
        return self.lab_down.winfo_id()

    def winloop(self):
        self.root.mainloop()

    def close(self):
        clear_xterm()
        self.root.destroy()
        #self.root.quit()

    

if __name__ == "__main__":

    win = tkwin()
    win.createwin()

    wid = win.get_winid()
    xtermop = xterm_option()
    xtermop.set_xterm(wid)

    th = mythread_1(get_screen_size, (wid, win.root, win.lab_up, win.lab_down, xtermop))
    th.run()

    win.winloop()
